let nomeEstudante;
const professora = 'Ana';

console.log(nomeEstudante);
console.log(typeof nomeEstudante);
console.log(typeof professora);

let telefoneEstudante = null;

console.log(typeof telefoneEstudante);