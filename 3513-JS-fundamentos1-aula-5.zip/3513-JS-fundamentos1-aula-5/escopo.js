const estudante = 'Caroline';

if (1 > 0) {
  console.log(estudante);
}

console.log(estudante);