const estudante = 'Caroline';
let professora;

professora = 'Ana';

console.log(estudante, professora);