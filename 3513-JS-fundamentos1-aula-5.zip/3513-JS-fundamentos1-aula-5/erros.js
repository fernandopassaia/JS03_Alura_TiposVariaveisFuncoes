// console.log(variavel);
console.log('oi'